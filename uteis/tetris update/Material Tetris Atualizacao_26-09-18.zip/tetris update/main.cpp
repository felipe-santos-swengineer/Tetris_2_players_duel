#include <SFML/Graphics.hpp>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>


typedef struct p{
    double px;
    double py;
} Coord; //vai guardar os valores de x e y de cada quadrado q vai montar a pe�a

typedef struct p2{
    int px;
    int py;
} Coord2;
Coord matrizdevalxy[10][20];



//############################################### INT MAIN #############################################################################
int main(){
    srand(time(NULL));

    //******************** DECLARA�AO DE VARIAVEIS ********************************************************
    int i, j, mov_y=0, mov_x=4; //mov_y e mov_x � usado para incrementar a pe�a na matriz principal, no eix x e eixo y | MOV_X=4 para come�ar no meio
    int delay=0; // serve para dar um delay de 3 segundos antes da pe�a descer
    int aleatorioPeca; //vai receber um numero aleatorio entre 0 e 9;
    int aleatorioCor; //vai receber um numero aleatorio entre 0 e 5;
    int limitedapeca=0; //valor que vai controlar o limite da pe�a em rela�ao a borda inferior. ele � igual ao maior valor da pe�a no eixo y;
    //****************************************************************************



    //****************** COLOCANDO VALORES NO VETOR DE STRING **********************************************************
    std::string cores[5]; //cada posicao tera uma string com o caminho do arquivo
    cores[0]="img/svg1.png";
    cores[1]="img/svg2.png";
    cores[2]="img/svg3.png";
    cores[3]="img/svg4.png";
    cores[4]="img/svg5.png";

     //*******************************************************************************************



    //****************** PADRAO DE PE�AS ( 9 TIPOS DE PE�AS DIFERENTES )**********************************************************
    //matriz em que cada coluna representa uma pe�a e as 4 linhas estao ponto x e ponto y da pe�a.
    Coord2 coordenadasdaspecas [9][4];
    //01 barra
    coordenadasdaspecas[0][0].px=0;
    coordenadasdaspecas[0][0].py=0;
    coordenadasdaspecas[0][1].px=0;
    coordenadasdaspecas[0][1].py=1;
    coordenadasdaspecas[0][2].px=0;
    coordenadasdaspecas[0][2].py=2;
    coordenadasdaspecas[0][3].px=0;
    coordenadasdaspecas[0][3].py=3;
    //02 N invertido
    coordenadasdaspecas[1][0].px=0;
    coordenadasdaspecas[1][0].py=0;
    coordenadasdaspecas[1][1].px=0;
    coordenadasdaspecas[1][1].py=1;
    coordenadasdaspecas[1][2].px=1;
    coordenadasdaspecas[1][2].py=1;
    coordenadasdaspecas[1][3].px=1;
    coordenadasdaspecas[1][3].py=2;
    //03 quadrado
    coordenadasdaspecas[2][0].px=0;
    coordenadasdaspecas[2][0].py=0;
    coordenadasdaspecas[2][1].px=1;
    coordenadasdaspecas[2][1].py=0;
    coordenadasdaspecas[2][2].px=0;
    coordenadasdaspecas[2][2].py=1;
    coordenadasdaspecas[2][3].px=1;
    coordenadasdaspecas[2][3].py=1;
    //04 N comum
    coordenadasdaspecas[3][0].px=0;
    coordenadasdaspecas[3][0].py=1;
    coordenadasdaspecas[3][1].px=0;
    coordenadasdaspecas[3][1].py=2;
    coordenadasdaspecas[3][2].px=1;
    coordenadasdaspecas[3][2].py=0;
    coordenadasdaspecas[3][3].px=1;
    coordenadasdaspecas[3][3].py=1;
    //05 Z comum
    coordenadasdaspecas[4][0].px=0;
    coordenadasdaspecas[4][0].py=0;
    coordenadasdaspecas[4][1].px=1;
    coordenadasdaspecas[4][1].py=0;
    coordenadasdaspecas[4][2].px=1;
    coordenadasdaspecas[4][2].py=1;
    coordenadasdaspecas[4][3].px=2;
    coordenadasdaspecas[4][3].py=1;
    //06 S
    coordenadasdaspecas[5][0].px=0;
    coordenadasdaspecas[5][0].py=1;
    coordenadasdaspecas[5][1].px=1;
    coordenadasdaspecas[5][1].py=1;
    coordenadasdaspecas[5][2].px=1;
    coordenadasdaspecas[5][2].py=0;
    coordenadasdaspecas[5][3].px=2;
    coordenadasdaspecas[5][3].py=0;
    //07 T
    coordenadasdaspecas[6][0].px=0;
    coordenadasdaspecas[6][0].py=0;
    coordenadasdaspecas[6][1].px=1;
    coordenadasdaspecas[6][1].py=0;
    coordenadasdaspecas[6][2].px=1;
    coordenadasdaspecas[6][2].py=1;
    coordenadasdaspecas[6][3].px=2;
    coordenadasdaspecas[6][3].py=0;
    //08 L comum
    coordenadasdaspecas[7][0].px=0;
    coordenadasdaspecas[7][0].py=0;
    coordenadasdaspecas[7][1].px=0;
    coordenadasdaspecas[7][1].py=1;
    coordenadasdaspecas[7][2].px=0;
    coordenadasdaspecas[7][2].py=2;
    coordenadasdaspecas[7][3].px=1;
    coordenadasdaspecas[7][3].py=2;
    //09 L invertido
    coordenadasdaspecas[8][0].px=1;
    coordenadasdaspecas[8][0].py=0;
    coordenadasdaspecas[8][1].px=1;
    coordenadasdaspecas[8][1].py=1;
    coordenadasdaspecas[8][2].px=1;
    coordenadasdaspecas[8][2].py=2;
    coordenadasdaspecas[8][3].px=0;
    coordenadasdaspecas[8][3].py=2;

    //****************************************************************************




    //********** PREENCHENDO A MATRZ DE VALORES COM AS POSICOES X E Y CORRETAS, DE ACORDO COM O i E j ****************
    //setando valores das posicoes x e y de todas as pe�as
    for(i=0;i<10;i++){
        for(j=0;j<20;j++){
            matrizdevalxy[i][j].px=(i*20.8)+190.0; //i multiplica pois � a coluna ; 20.8 px � o recuo da pe�a no eixo x quando pressionado (largura)
            matrizdevalxy[i][j].py=(j*20.7)+108.0; //j multiplica pois � a linha ; 20.7 px � o recuo da pe�a no eixo y quando pressionado  (altura)
        }
    }

    //****************************************************************************



    sf::RenderWindow janela(sf::VideoMode(1050, 591), "Trabalho Pablo");

    sf::Clock clock;

    sf::Texture texturabg;
    texturabg.loadFromFile("img/background.png");

    sf::Texture textura2;
    textura2.loadFromFile("img/svg4.png");

    aleatorioCor=rand()%5; // seta um valor aleatorio para carregar o arquivo de cor diferente a cada pe�a
    sf::Texture texturaStatica;
    texturaStatica.loadFromFile(cores[aleatorioCor]);

    aleatorioPeca=rand()%9;

//############################################### COME�O DO LOOP #############################################################################
while (janela.isOpen()){

    bool matrizPlayer[10][20];

    //******************** SETA FALSE EM TODAS AS POSICOES DA MATRIZ PRINCIPAL *****************************
    //matriz do jogo come�a com valores false em todas as posi��es;
    for(i=0;i<10;i++){
        for(j=0;j<20;j++){
            matrizPlayer[i][j]=false;
        }
    }

    //****************************************************************************




    //********************** SETA VALORES TRUE DE ACORDO CO A MATRIZ DAS PE�AS ************************************
    //coordenadas passadas para matrizplayer de booleanos atravez da matriz coodenadas pecas px e py
    //esse la�o for � feito dentro do loop principal, e pode ser incremeentado com valores mov_x e mov_y para os movimentos
    //matriz player � a matriz de booleanos principal, e esta sendo passado como parametro a coordenadas das pe�as
    //a coluna � gerada no rand() aleatorioPeca, e a posicao de x e y q existe na struct e passada para a matriz principal.

    for(j=0;j<4;j++){
        matrizPlayer[coordenadasdaspecas[aleatorioPeca][j].px + mov_x][coordenadasdaspecas[aleatorioPeca][j].py + mov_y]=true;//mov_y e mov_x usados para mover a peca
        //a partir daqui vai ser setado o valor do limite da pe�a de acordo com o valor de y;
        //para a pe�a parar no lugar certo independente do tamanho (altura)
        if(j==0){
            limitedapeca=coordenadasdaspecas[aleatorioPeca][0].py;
        } else {
            if(limitedapeca<=coordenadasdaspecas[aleatorioPeca][j].py){
                limitedapeca=coordenadasdaspecas[aleatorioPeca][j].py;
            }
        }


    }

    //****************************************************************************




    sf::Sprite background;
    background.setTexture(texturabg);
    background.setPosition(sf::Vector2f(0,0));

    sf::Sprite spriteStatico;
    spriteStatico.setTexture(texturaStatica);




        //****************************** EVENTOS DE PRESSIONADO DE BOTOES **********************************************
        sf::Event evento;
        while (janela.pollEvent(evento)){
            if(evento.type==sf::Event::Closed){
            janela.close();
        } else if (evento.type==sf::Event::KeyPressed){

            if (evento.key.code==sf::Keyboard::Right){
                mov_x++;
            }
            if (evento.key.code==sf::Keyboard::Left){
                mov_x--;
            }
            if(evento.key.code==sf::Keyboard::Up){
                mov_y--;
            }
            if(evento.key.code==sf::Keyboard::Down){
                mov_y++;

            }
        }
        }
        //****************************************************************************




        janela.clear(sf::Color(255,255,255));
        janela.draw(background);




        //************************* IMPRIME OS TRUE DA MATRIZ PRINCIPAL *********************************
        //la�o for verifica toda a matriz em busca de um true para imprimir.
        //se for true, ele imprime a figura com a matriz de valores na mesma posicao
        for(i=0;i<10;i++){
            for(j=0;j<20;j++){
                if(matrizPlayer[i][j]){
                  spriteStatico.setPosition(sf::Vector2f(matrizdevalxy[i][j].px, matrizdevalxy[i][j].py));
                    janela.draw(spriteStatico);

                }
            }
        }
        //****************************************************************************





        //***************************** TIME DO JOGO ***********************************************

        if(clock.getElapsedTime().asSeconds()>0.4){
           delay++;
           if(delay>=3 && mov_y<=18-limitedapeca){ // limite de incrementa�ao ate em baixo vairoa com o tamanho da pe�a (limitepeca)
            mov_y++;
           }
            clock.restart();
        }
        //parte do clock do jogo;
        //fun�ao retoorna o valor em segundos da execu�ao, e de acordo com a
        //comparacao se define a velocidade qque a pe�a cai,
        // usando o incremento mov_y

        //****************************************************************************

        janela.display();
       // printf("limite: %d", limitedapeca);
    }
//############################################### FIM DO LOOP #############################################################################

    return 0;
}


